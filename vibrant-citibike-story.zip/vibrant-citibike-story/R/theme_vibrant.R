# A bold, saturated ggplot2 theme + palette for this project -- built for
# an infographic-style report, not a muted analytical one. Dark background,
# bright gradient fills, big bold titles.

library(ggplot2)

theme_vibrant <- function(base_size = 13) {
  theme_minimal(base_size = base_size, base_family = "sans") +
    theme(
      plot.background     = element_rect(fill = "#0f172a", colour = NA),
      panel.background    = element_rect(fill = "#0f172a", colour = NA),
      panel.grid.major    = element_line(colour = "#1e293b", linewidth = 0.3),
      panel.grid.minor    = element_blank(),
      text                 = element_text(colour = "#e2e8f0"),
      axis.text            = element_text(colour = "#94a3b8"),
      plot.title.position = "plot",
      plot.title           = element_text(face = "bold", size = rel(1.6), colour = "#f8fafc"),
      plot.subtitle         = element_text(colour = "#94a3b8", margin = margin(b = 12), size = rel(1.05)),
      plot.caption           = element_text(colour = "#64748b", hjust = 0, size = rel(0.75)),
      legend.position          = "top",
      legend.title             = element_blank(),
      legend.text              = element_text(colour = "#e2e8f0"),
      strip.text                = element_text(colour = "#f8fafc", face = "bold"),
      plot.margin                = margin(18, 18, 14, 18)
    )
}

# A hot, saturated gradient -- used for heatmaps (ride volume by hour/day)
vibrant_gradient <- c("#1e1b4b", "#4c1d95", "#9333ea", "#ec4899", "#f97316", "#fde047")

# A punchy discrete palette -- used for member vs casual, or day types
vibrant_discrete <- c("#22d3ee", "#f472b6", "#facc15", "#4ade80")
