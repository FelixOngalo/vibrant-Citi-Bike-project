library(readr)
source("R/cleaning.R")

raw   <- read_csv("data/raw/citibike_trips.csv", show_col_types = FALSE)
clean <- clean_trips(raw)

cat("Rows before:", nrow(raw), "\n")
cat("Rows after: ", nrow(clean), "\n")
cat("Date range: ", as.character(min(clean$started_at)), "to", as.character(max(clean$started_at)), "\n")

saveRDS(clean, "data/clean/trips_clean.rds")
