library(dplyr)
library(lubridate)
library(janitor)

clean_trips <- function(raw) {
  raw |>
    clean_names() |>
    mutate(
      started_at   = as_datetime(started_at),
      ended_at     = as_datetime(ended_at),
      duration_min = as.numeric(difftime(ended_at, started_at, units = "mins")),
      hour         = hour(started_at),
      weekday      = wday(started_at, label = TRUE, week_start = 1),
      day_type     = if_else(wday(started_at, week_start = 1) <= 5, "Weekday", "Weekend"),
      member_casual = factor(member_casual, levels = c("member", "casual"))
    ) |>
    filter(duration_min > 1, duration_min < 180)   # drop bad clock resets and outlier rides
}
