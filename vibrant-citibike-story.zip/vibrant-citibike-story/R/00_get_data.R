# Data: Citi Bike (NYC) trip history -- free, public, no signup.
# https://citibikenyc.com/system-data
# Download one month's trip CSV (e.g. "202506-citibike-tripdata.csv.zip"),
# unzip, and place the CSV at data/raw/citibike_trips.csv
#
# Columns (recent format): ride_id, rideable_type, started_at, ended_at,
# start_station_name, start_lat, start_lng, end_station_name, end_lat,
# end_lng, member_casual
#
# Pick a summer month if you want the most vibrant/colorful riding
# patterns (more volume, more variety in ride types and times).
message("Download one month of Citi Bike trip data to data/raw/citibike_trips.csv")
