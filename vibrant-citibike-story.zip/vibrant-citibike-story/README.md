# A Month in Motion: A Vibrant Citi Bike Data Story

**What this is:** a one-page, infographic-style data story — bold colors, big headline stats, a dark theme — built to show design and storytelling skill alongside analysis. Most portfolio pieces are "neutral analyst" in tone; this one is deliberately a visual statement piece.

**Question:** How does a city move across a month of bike-share rides — when, how long, and who (member vs. casual)?

**Tools:** R, tidyverse, ggplot2 (custom dark/vibrant theme), Quarto

## Reproduce

1. Download one month of Citi Bike trip data (see `R/00_get_data.R`) to `data/raw/citibike_trips.csv` — a summer month gives the most vivid, high-volume patterns
2. `install.packages(c("tidyverse", "janitor", "scales", "quarto"))`
3. Run `R/01_clean.R`
4. Render `reports/story.qmd`

## Design notes

- `R/theme_vibrant.R` holds a reusable dark-background ggplot2 theme (`theme_vibrant()`) and two palettes: a hot gradient (`vibrant_gradient`, used for the hour×weekday heatmap) and a punchy discrete palette (`vibrant_discrete`, used for member/casual comparisons). Pulling these into one file means every chart in the report matches, and the theme is reusable in future vibrant-style projects.
- The report itself uses raw HTML (`<div>` flex layout) for the headline stat row — a deliberate choice to make the numbers feel like a dashboard tile row rather than a table, which plain Quarto/markdown can't do on its own.
- `theme: darkly` in the Quarto YAML sets a dark page background so the chart backgrounds blend into the page instead of sitting in white boxes.

## Structure

```
R/00_get_data.R       Citi Bike data source link
R/cleaning.R           cleaning function (duration, hour, weekday, day type)
R/01_clean.R            run cleaning
R/theme_vibrant.R       shared dark theme + vibrant color palettes
reports/story.qmd       the full infographic-style report
```

## Make it yours

- Swap in a different city's bike-share data (Chicago's Divvy, London's Santander Cycles use similar schemas) for a different flavor.
- Try the same `theme_vibrant()` on a different dataset entirely — it's written to be reusable, not tied to this one.
- Add an animated version with `gganimate` (ride volume building up hour by hour) if you want to push the "vibrant" angle further.
